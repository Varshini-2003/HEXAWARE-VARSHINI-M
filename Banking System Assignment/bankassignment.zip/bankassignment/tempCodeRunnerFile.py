from dao.customer_dao import CustomerDAO
from dao.account_dao import AccountDAO
from dao.transaction_dao import TransactionDAO
from entity.customer import Customer
from entity.account import Account
from entity.transaction import Transaction
from utils.validators import validate_email, validate_phone, validate_amount
from exception.invalid_input_exception import InvalidInputException
import datetime

def main():
    print("=== Welcome to the Banking System ===")
    print("1. Add Customer")
    print("2. Add Account")
    print("3. Make Transaction")
    choice = input("Enter your choice (1-3): ")

    if choice == "1":
        try:
            cid = int(input("Enter Customer ID: "))
            name = input("Enter Name: ")
            email = input("Enter Email: ")
            phone = input("Enter Phone: ")

            validate_email(email)
            validate_phone(phone)

            customer = Customer(cid, name, email, phone)
            dao = CustomerDAO()
            dao.add_customer(customer)
            print("✅ Customer added successfully!")

        except InvalidInputException as e:
            print("❌ Validation Error:", e)
        except Exception as e:
            print("❌ Error:", e)

    elif choice == "2":
        try:
            aid = int(input("Enter Account ID: "))
            cid = int(input("Enter Customer ID: "))
            balance = float(input("Enter Balance: "))
            atype = input("Enter Account Type: ")

            validate_amount(balance)

            account = Account(aid, cid, balance, atype)
            dao = AccountDAO()
            dao.add_account(account)
            print("✅ Account added successfully!")

        except InvalidInputException as e:
            print("❌ Validation Error:", e)
        except Exception as e:
            print("❌ Error:", e)

    elif choice == "3":
        try:
            tid = int(input("Enter Transaction ID: "))
            aid = int(input("Enter Account ID: "))
            amount = float(input("Enter Amount: "))
            ttype = input("Enter Transaction Type (deposit/withdraw): ")

            validate_amount(amount)

            txn = Transaction(tid, aid, amount, ttype, datetime.datetime.now())
            dao = TransactionDAO()
            dao.add_transaction(txn)
            print("✅ Transaction added successfully!")

        except InvalidInputException as e:
            print("❌ Validation Error:", e)
        except Exception as e:
            print("❌ Error:", e)

    else:
        print("❌ Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
