def password_validation(password):
    length = len(password) >= 8
    uppercase = any(char.isupper() for char in password)
    digit = any(char.isdigit() for char in password)
    
    if length and uppercase and digit:
        print("Password is valid.")
    else:
        print("Password is invalid.")
        if not length:
            print("- Password must be at least 8 characters long.")
        if not uppercase:
            print("- Password must contain at least one uppercase letter.")
        if not digit:
            print("- Password must contain at least one digit.")

password_validation("12345hhbc")