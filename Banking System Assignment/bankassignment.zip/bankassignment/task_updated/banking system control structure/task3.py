n = int(input("Enter the number of customers: "))

for i in range(n):
    print(f"\nFor Customer {i + 1}:")
    
    ib = float(input("Enter the initial balance: "))
    air = float(input("Enter the annual interest rate (%): "))
    ny = int(input("Enter the number of years: "))
    
    fb = ib * ((1 + air / 100) ** ny)
    
    print(f"The future balance of customer {i + 1} is {fb:.2f}")
