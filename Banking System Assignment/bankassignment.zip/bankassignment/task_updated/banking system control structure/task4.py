accounts = {
    "1001": 25000.50,
    "1002": 15000.00,
    "1003": 3400.75,
    "1004": 78000.20,
    "1005": 500.00
}

print("Welcome to the Bank Balance Checker")

while True:
    account = input("Enter your account number (or type 'exit' to quit): ")

    if account.lower() == 'exit':
        print("Thank you for using the service. Goodbye!")
        break

    if account in accounts:
        print(f" Account found. Your current balance is {accounts[account]:.2f}")
        break
    else:
        print(" Invalid account number. Please try again.")
