credit=int(input("Enter the credit score : "))
annual=int(input("Enter the annual income : "))
if(credit>700 and annual>=50000):
    print("Eligible for Loan")
else:
    print("Not Eligible for Loan")