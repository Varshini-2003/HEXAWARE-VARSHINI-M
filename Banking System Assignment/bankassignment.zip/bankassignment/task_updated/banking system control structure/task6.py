def transaction_tracker():
    transactions = []
    print("Welcome to Your Bank Transaction Tracker!")

    while True:
        print("\nChoose a transaction:")
        print("1. Deposit")
        print("2. Withdrawal")
        print("3. Display transaction")
        print("4. Exit")

        choice = input("Enter your choice (1/2/3/4): ")

        if choice == '1':
            amount = float(input("Enter deposit amount: "))
            transactions.append(("Deposit", amount))
            print(f"{amount} deposited successfully.")

        elif choice == '2':
            amount = float(input("Enter withdrawal amount: "))
            transactions.append(("Withdrawal", amount))
            print(f"{amount} withdrawn successfully.")

        elif choice=='3':
            for x in transactions:
                print(x)
            print("")
        elif choice == '4':
            print("\n Exiting... Here is your transaction history:")
            break
        
        else:
            print("Invalid choice. Please enter 1, 2, or 3.")

    print("\n Transaction History:")
    if not transactions:
        print("No transactions made.")
    else:
        for i, (t_type, amt) in enumerate(transactions, start=1):
            print(f"{i}. {t_type} - {amt}")

transaction_tracker()