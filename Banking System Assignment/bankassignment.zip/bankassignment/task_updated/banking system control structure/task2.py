def atm():
    bal=float(input("Enter Balance Amt : "))
    while True:
        print("1.Check Balance")
        print("2.Withdraw")
        print("3.Deposit")
        print("4.Exit")
        ch=int(input("Enter your choice : "))
        if ch==1:
            print(f"Your Current Balance is {bal} rs")
        elif ch==2:
            amt=int(input("Enter the amount you want to withdraw : "))
            if(amt<0):
                print("Enter a valid amount to withdraw : ")
            elif(amt%100!=0):
                print("Enter amt in multiples of 100 and 500 ")
            elif(amt>bal):
                print("Insufficient balance ")
            else:
                bal-=amt 
                print(f"Withdrawal successfull new balance is {bal}")
        elif ch==3:
            dep=int(input("Enter the amount to be deposited : "))
            if dep<0:
                print("Enter a valid amount : ")
            else:
                bal+=dep 
                print(f"{dep} rs deposited the new balance is {bal}")
        elif ch==4:
            break
        else:
            print("Enter a valid choice input")

atm()