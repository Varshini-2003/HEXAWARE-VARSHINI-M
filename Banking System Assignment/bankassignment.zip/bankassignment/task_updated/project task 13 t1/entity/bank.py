from .Account import *
class Bank:
    def __init__(self):
        self.accounts = []
        self.easy_find=[]
        self.current_account_number = 1001

    def create_account(self, customer, acc_type, balance):
        acc_no = self.current_account_number
        self.current_account_number += 1
        new_account = Account(acc_no, acc_type, balance, customer)
        self.accounts.append([acc_no,new_account])
        self.easy_find.append(acc_no)
        print(f"Account created successfully with Account Number: {acc_no}")
        return acc_no

    def get_account_balance(self, acc_no):
        if acc_no in self.accounts:
            return self.accounts[self.easy_find.index(acc_no)][-1].balance
        raise ValueError("Account not found")

    def deposit(self, acc_no, amount):
        if acc_no in self.accounts:
            return self.accounts[self.easy_find.index(acc_no)][-1].deposit(amount)
        raise ValueError("Account not found")

    def withdraw(self, acc_no, amount):
        if acc_no in self.accounts:
            return self.accounts[self.easy_find.index(acc_no)][-1].withdraw(amount)
        raise ValueError("Account not found")

    def transfer(self, from_acc, to_acc, amount):
        if(from_acc==to_acc):
            raise ValueError("Same source and destination")
        if from_acc in self.easy_find and to_acc in self.easy_find:
            self.withdraw(from_acc, amount)
            self.deposit(to_acc, amount)
        else:
            raise ValueError("One or both accounts not found")

    def get_account_details(self, acc_no):
        if acc_no in self.accounts:
            self.accounts[self.easy_find.index(acc_no)][-1].print_info()
        else:
            raise ValueError("Account not found")
