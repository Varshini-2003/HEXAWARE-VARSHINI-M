from entity.bank import Bank
if __name__ == "__main__":
    bank = Bank()
    bank.create_account()
    bank.operate()
